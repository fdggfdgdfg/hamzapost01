import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:webfeed/webfeed.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import '../models/article.dart';

class FeedItem {
  final String id;
  final String name;
  final String topic;
  final String language;
  final String url;
  FeedItem({required this.id, required this.name, required this.topic, required this.language, required this.url});

  factory FeedItem.fromMap(Map<String, dynamic> m) => FeedItem(
    id: m['id'] ?? m['name'],
    name: m['name'] ?? '',
    topic: m['topic'] ?? 'general',
    language: m['language'] ?? 'ar',
    url: m['url'],
  );
}

class FeedService extends ChangeNotifier {
  List<FeedItem> feeds = [];
  List<Article> articles = [];
  DateTime? _lastFetch;
  String _selectedTopic = 'all';
  String _selectedSource = 'all';
  bool isLoading = false;

  String get selectedTopic => _selectedTopic;
  String get selectedSource => _selectedSource;

  Future<void> loadFeeds() async {
    final txt = await rootBundle.loadString('assets/feeds.json');
    final data = json.decode(txt) as List;
    feeds = data.map((e) => FeedItem.fromMap(e)).toList();
    await refresh();
  }

  Future<void> refresh() async {
    // Cache for 60 minutes
    if (_lastFetch != null && DateTime.now().difference(_lastFetch!).inMinutes < 60 && articles.isNotEmpty) {
      return;
    }
    isLoading = true;
    notifyListeners();
    final List<Article> all = [];
    for (final f in feeds) {
      try {
        final res = await http.get(Uri.parse(f.url));
        if (res.statusCode == 200) {
          final feed = RssFeed.parse(res.body);
          for (final item in feed.items ?? []) {
            final link = item.link ?? (item.guid?.value ?? '');
            if (link.isEmpty) continue;
            all.add(Article(
              title: item.title ?? '',
              description: item.description,
              link: link,
              source: item.source?.value ?? f.name,
              pubDate: item.pubDate,
              imageUrl: item.media?.thumbnails?.isNotEmpty == true ? item.media!.thumbnails!.first.url : null,
            ));
          }
        }
      } catch (e) {
        if (kDebugMode) {
          print('Error fetching ${f.name}: $e');
        }
      }
    }
    // simple sort by date desc if available
    all.sort((a, b) {
      final aTime = a.pubDate?.millisecondsSinceEpoch ?? 0;
      final bTime = b.pubDate?.millisecondsSinceEpoch ?? 0;
      return bTime.compareTo(aTime);
    });
    articles = all;
    _lastFetch = DateTime.now();
    isLoading = false;
    notifyListeners();
  }

  List<String> get topics => ['all', ...{for (final f in feeds) f.topic}];
  List<String> get sources => ['all', ...{for (final f in feeds) f.name}];

  void setTopic(String t) { _selectedTopic = t; notifyListeners(); }
  void setSource(String s) { _selectedSource = s; notifyListeners(); }

  List<Article> get filtered {
    return articles.where((a) {
      final okTopic = _selectedTopic == 'all' || feeds.any((f) => f.name == a.source && f.topic == _selectedTopic);
      final okSource = _selectedSource == 'all' || a.source == _selectedSource;
      return okTopic && okSource;
    }).toList();
  }

  String prettyDate(DateTime? dt) {
    if (dt == null) return '';
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inMinutes < 60) return '${diff.inMinutes} دقيقة';
    if (diff.inHours < 24) return '${diff.inHours} ساعة';
    return DateFormat('yyyy-MM-dd HH:mm').format(dt);
  }
}