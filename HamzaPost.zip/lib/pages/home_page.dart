import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/feed_service.dart';
import '../models/article.dart';
import 'webview_page.dart' show openArticle;

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    final feed = context.watch<FeedService>();
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('أخبار المغرب - HamzaPost'),
          actions: [
            IconButton(
              onPressed: () => feed.refresh(),
              icon: const Icon(Icons.refresh),
              tooltip: 'تحديث',
            ),
          ],
        ),
        drawer: Drawer(
          child: SafeArea(
            child: ListView(
              padding: const EdgeInsets.all(12),
              children: [
                const ListTile(title: Text('تصفية حسب الموضوع')),
                Wrap(
                  spacing: 8,
                  children: feed.topics.map((t) => ChoiceChip(
                    label: Text(t),
                    selected: feed.selectedTopic == t,
                    onSelected: (_) => feed.setTopic(t),
                  )).toList(),
                ),
                const Divider(),
                const ListTile(title: Text('تصفية حسب المصدر')),
                Wrap(
                  spacing: 8,
                  children: feed.sources.map((s) => ChoiceChip(
                    label: Text(s),
                    selected: feed.selectedSource == s,
                    onSelected: (_) => feed.setSource(s),
                  )).toList(),
                ),
                const Divider(),
                const ListTile(
                  title: Text('سياسة الخصوصية'),
                  subtitle: Text('المحتوى ملك لمصادره، يتم عرض مقتطفات فقط.'),
                )
              ],
            ),
          ),
        ),
        body: feed.isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: feed.filtered.length,
                itemBuilder: (ctx, i) => ArticleCard(article: feed.filtered[i]),
              ),
      ),
    );
  }
}

class ArticleCard extends StatelessWidget {
  final Article article;
  const ArticleCard({super.key, required this.article});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () => openArticle(context, article.link),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (article.imageUrl != null)
                AspectRatio(
                  aspectRatio: 16/9,
                  child: Image.network(article.imageUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox.shrink()),
                ),
              const SizedBox(height: 8),
              Text(article.title, style: Theme.of(context).textTheme.titleMedium, textDirection: TextDirection.rtl),
              const SizedBox(height: 6),
              if (article.description != null)
                Text(article.description!.replaceAll(RegExp(r'<[^>]*>'), ''), maxLines: 3, overflow: TextOverflow.ellipsis, textDirection: TextDirection.rtl),
              const SizedBox(height: 8),
              Row(
                children: [
                  Expanded(child: Text(article.source, style: const TextStyle(fontWeight: FontWeight.w500))),
                  Text(context.read<FeedService>().prettyDate(article.pubDate)),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}