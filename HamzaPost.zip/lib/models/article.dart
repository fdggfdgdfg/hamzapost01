class Article {
  final String title;
  final String? description;
  final String link;
  final String source;
  final DateTime? pubDate;
  final String? imageUrl;

  Article({
    required this.title,
    required this.link,
    required this.source,
    this.description,
    this.pubDate,
    this.imageUrl,
  });
}